import type { Express } from "express";
import { createServer, type Server } from "http";
import { storage } from "./storage";
import { api } from "@shared/routes";
import { setupAuth, registerAuthRoutes } from "./replit_integrations/auth";
import { z } from "zod";

export async function registerRoutes(
  httpServer: Server,
  app: Express
): Promise<Server> {
  // Auth Setup
  await setupAuth(app);
  registerAuthRoutes(app);

  // === POSTS ===
  app.get(api.posts.list.path, async (req, res) => {
    const posts = await storage.getPosts();
    // Fetch authors for each post (could be optimized with a join, but simple loop is fine for MVP)
    const postsWithAuthors = await Promise.all(posts.map(async (post) => {
      const author = await storage.getUser(post.authorId);
      return { ...post, author };
    }));
    res.json(postsWithAuthors);
  });

  app.get(api.posts.get.path, async (req, res) => {
    const post = await storage.getPost(Number(req.params.id));
    if (!post) return res.status(404).json({ message: "Post not found" });

    const author = await storage.getUser(post.authorId);
    const comments = await storage.getComments(post.id);
    
    // Fetch authors for comments
    const commentsWithAuthors = await Promise.all(comments.map(async (c) => {
      const cAuthor = await storage.getUser(c.authorId);
      return { ...c, author: cAuthor };
    }));

    res.json({ ...post, author, comments: commentsWithAuthors });
  });

  app.post(api.posts.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    try {
      const input = api.posts.create.input.parse(req.body);
      const user = req.user as any; // Replit Auth user object
      
      const post = await storage.createPost({
        ...input,
        authorId: user.claims.sub, // Use the stable ID from Replit Auth
      });

      const author = await storage.getUser(post.authorId);
      res.status(201).json({ ...post, author });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  app.delete(api.posts.delete.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });
    
    const post = await storage.getPost(Number(req.params.id));
    if (!post) return res.status(404).json({ message: "Not found" });

    const user = req.user as any;
    if (post.authorId !== user.claims.sub) {
      return res.status(403).json({ message: "Forbidden" });
    }

    await storage.deletePost(post.id);
    res.sendStatus(204);
  });

  // === COMMENTS ===
  app.post(api.comments.create.path, async (req, res) => {
    if (!req.isAuthenticated()) return res.status(401).json({ message: "Unauthorized" });

    try {
      const input = api.comments.create.input.parse(req.body);
      const user = req.user as any;

      const comment = await storage.createComment({
        ...input,
        authorId: user.claims.sub,
      });

      const author = await storage.getUser(comment.authorId);
      res.status(201).json({ ...comment, author });
    } catch (err) {
      if (err instanceof z.ZodError) {
        return res.status(400).json({ message: err.errors[0].message });
      }
      throw err;
    }
  });

  // === STOCKS (Mock Data) ===
  app.get(api.stocks.list.path, async (req, res) => {
    // Seed if empty
    const existing = await storage.getStocks();
    if (existing.length === 0) {
      await seedStocks();
      return res.json(await storage.getStocks());
    }
    
    // Simulate live changes
    const stocks = await Promise.all(existing.map(async (s) => {
        // Random fluctuation between -50 and +50 cents
        const fluctuation = Math.floor(Math.random() * 101) - 50; 
        return { ...s, price: Math.max(100, s.price + fluctuation), change: fluctuation };
    }));
    
    res.json(stocks);
  });

  return httpServer;
}

async function seedStocks() {
  const stocks = [
    { symbol: "MOL", name: "Molozon Corp", price: 15420, change: 230 },
    { symbol: "ZON", name: "ZonTech", price: 4250, change: -120 },
    { symbol: "GLX", name: "Galaxy Systems", price: 8900, change: 450 },
    { symbol: "NEB", name: "Nebula Ind", price: 1200, change: 50 },
    { symbol: "QNT", name: "Quantum Leap", price: 3300, change: -80 },
  ];
  
  for (const s of stocks) {
    // We can cast because we're seeding with mock IDs effectively (ignoring serial for insert)
    await storage.createStock(s as any);
  }
}
