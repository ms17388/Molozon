import { pgTable, text, serial, integer, boolean, timestamp, varchar, index } from "drizzle-orm/pg-core";
import { relations } from "drizzle-orm";
import { createInsertSchema } from "drizzle-zod";
import { z } from "zod";
import { users } from "./models/auth";

export * from "./models/auth";

// === TABLE DEFINITIONS ===

export const posts = pgTable("posts", {
  id: serial("id").primaryKey(),
  title: text("title").notNull(),
  content: text("content").notNull(),
  authorId: varchar("author_id").notNull(), // References users.id (which is string from auth)
  upvotes: integer("upvotes").default(0),
  downvotes: integer("downvotes").default(0),
  createdAt: timestamp("created_at").defaultNow(),
});

export const comments = pgTable("comments", {
  id: serial("id").primaryKey(),
  content: text("content").notNull(),
  authorId: varchar("author_id").notNull(),
  postId: integer("post_id").notNull(),
  createdAt: timestamp("created_at").defaultNow(),
});

export const stocks = pgTable("stocks", {
  id: serial("id").primaryKey(),
  symbol: varchar("symbol", { length: 10 }).notNull().unique(),
  name: text("name").notNull(),
  price: integer("price").notNull(), // Stored in cents
  change: integer("change").notNull(), // Stored in cents (can be negative)
});

// === RELATIONS ===

export const postsRelations = relations(posts, ({ one, many }) => ({
  author: one(users, {
    fields: [posts.authorId],
    references: [users.id],
  }),
  comments: many(comments),
}));

export const commentsRelations = relations(comments, ({ one }) => ({
  author: one(users, {
    fields: [comments.authorId],
    references: [users.id],
  }),
  post: one(posts, {
    fields: [comments.postId],
    references: [posts.id],
  }),
}));

// === BASE SCHEMAS ===

export const insertPostSchema = createInsertSchema(posts).omit({ 
  id: true, 
  authorId: true, 
  upvotes: true, 
  downvotes: true, 
  createdAt: true 
});

export const insertCommentSchema = createInsertSchema(comments).omit({
  id: true,
  authorId: true,
  createdAt: true
});

// === EXPLICIT API CONTRACT TYPES ===

// Base types
export type Post = typeof posts.$inferSelect;
export type Comment = typeof comments.$inferSelect;
export type Stock = typeof stocks.$inferSelect;
export type User = typeof users.$inferSelect;

// Request types
export type CreatePostRequest = z.infer<typeof insertPostSchema>;
export type CreateCommentRequest = z.infer<typeof insertCommentSchema>;

// Response types - Enhanced with author info
export type PostWithAuthor = Post & { author: User | null };
export type CommentWithAuthor = Comment & { author: User | null };

export type PostResponse = PostWithAuthor;
export type PostDetailResponse = PostWithAuthor & { comments: CommentWithAuthor[] };
export type StockResponse = Stock;
