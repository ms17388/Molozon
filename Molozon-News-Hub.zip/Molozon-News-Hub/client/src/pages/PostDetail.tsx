import { useRoute } from "wouter";
import { usePost, useCreateComment } from "@/hooks/use-posts";
import { useAuth } from "@/hooks/use-auth";
import { Navbar } from "@/components/Navbar";
import { PostCard } from "@/components/PostCard";
import { Button } from "@/components/ui/button";
import { Textarea } from "@/components/ui/textarea";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Skeleton } from "@/components/ui/skeleton";
import { formatDistanceToNow } from "date-fns";
import { useForm } from "react-hook-form";
import { zodResolver } from "@hookform/resolvers/zod";
import { z } from "zod";
import { insertCommentSchema } from "@shared/schema";
import { Loader2, ArrowLeft } from "lucide-react";
import { Link } from "wouter";

export default function PostDetail() {
  const [match, params] = useRoute("/post/:id");
  const id = parseInt(params?.id || "0");
  const { data: post, isLoading, error } = usePost(id);
  const { user } = useAuth();
  const createComment = useCreateComment();

  const form = useForm<z.infer<typeof insertCommentSchema>>({
    resolver: zodResolver(insertCommentSchema),
    defaultValues: {
      content: "",
      postId: id,
    },
  });

  function onSubmit(data: z.infer<typeof insertCommentSchema>) {
    createComment.mutate(
      { ...data, postId: id },
      {
        onSuccess: () => form.reset(),
      }
    );
  }

  if (isLoading) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container max-w-4xl mx-auto px-4 pt-8">
           <Skeleton className="h-[400px] w-full rounded-xl bg-card/40" />
        </main>
      </div>
    );
  }

  if (error || !post) {
    return (
      <div className="min-h-screen bg-background">
        <Navbar />
        <main className="container max-w-4xl mx-auto px-4 pt-8 text-center">
          <h1 className="text-2xl font-bold text-destructive mb-4">Post not found</h1>
          <Button asChild><Link href="/">Back to Feed</Link></Button>
        </main>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <main className="container max-w-4xl mx-auto px-4 pt-8">
        <Button variant="ghost" className="mb-4 text-muted-foreground hover:text-foreground pl-0" asChild>
          <Link href="/">
            <ArrowLeft className="w-4 h-4 mr-2" />
            Back to Feed
          </Link>
        </Button>

        {/* Main Post Content */}
        <PostCard post={post} isDetail />

        {/* Comment Section */}
        <div className="bg-card/40 border border-t-0 border-white/5 rounded-b-xl p-4 md:p-8">
          
          {/* Comment Form */}
          {user ? (
            <form onSubmit={form.handleSubmit(onSubmit)} className="mb-10">
              <p className="text-sm text-muted-foreground mb-2">
                Comment as <span className="text-primary font-medium">{user.firstName || "User"}</span>
              </p>
              <div className="relative">
                <Textarea 
                  {...form.register("content")}
                  placeholder="What are your thoughts?"
                  className="min-h-[100px] bg-secondary/30 border-white/10 focus:border-primary focus:ring-1 focus:ring-primary resize-y pr-4"
                />
                <div className="absolute bottom-2 right-2">
                  <Button 
                    type="submit" 
                    size="sm"
                    disabled={createComment.isPending}
                    className="bg-primary hover:bg-primary/90"
                  >
                    {createComment.isPending ? <Loader2 className="w-3 h-3 animate-spin" /> : "Comment"}
                  </Button>
                </div>
              </div>
              {form.formState.errors.content && (
                <p className="text-xs text-destructive mt-1">{form.formState.errors.content.message}</p>
              )}
            </form>
          ) : (
             <div className="flex items-center justify-between p-4 bg-primary/5 border border-primary/20 rounded-lg mb-8">
               <p className="text-sm font-medium">Log in to join the discussion</p>
               <Button size="sm" asChild variant="secondary"><a href="/api/login">Log In</a></Button>
             </div>
          )}

          {/* Comment List */}
          <div className="space-y-6">
            <h3 className="font-display font-semibold text-lg border-b border-white/5 pb-2">
              {post.comments?.length || 0} Comments
            </h3>

            {post.comments?.length === 0 ? (
              <p className="text-muted-foreground text-center py-8">No comments yet.</p>
            ) : (
              post.comments?.map((comment) => (
                <div key={comment.id} className="group">
                  <div className="flex gap-3">
                    <Avatar className="h-8 w-8 ring-1 ring-white/10 mt-1">
                      <AvatarImage src={comment.author?.profileImageUrl || undefined} />
                      <AvatarFallback className="text-xs bg-secondary">
                        {comment.author?.firstName?.[0] || "U"}
                      </AvatarFallback>
                    </Avatar>
                    <div className="flex-1">
                      <div className="flex items-center gap-2 mb-1">
                        <span className="font-semibold text-sm hover:underline cursor-pointer">
                          {comment.author?.firstName || "Anonymous"}
                        </span>
                        <span className="text-xs text-muted-foreground">
                          {formatDistanceToNow(new Date(comment.createdAt || new Date()), { addSuffix: true })}
                        </span>
                      </div>
                      <div className="text-sm text-foreground/90 leading-relaxed">
                        {comment.content}
                      </div>
                      <div className="flex gap-4 mt-2">
                        <button className="text-xs font-medium text-muted-foreground hover:text-foreground flex items-center gap-1">
                          <ArrowBigUp className="w-4 h-4" /> Vote
                        </button>
                        <button className="text-xs font-medium text-muted-foreground hover:text-foreground">
                          Reply
                        </button>
                        <button className="text-xs font-medium text-muted-foreground hover:text-foreground">
                          Share
                        </button>
                      </div>
                    </div>
                  </div>
                </div>
              ))
            )}
          </div>
        </div>
      </main>
    </div>
  );
}
