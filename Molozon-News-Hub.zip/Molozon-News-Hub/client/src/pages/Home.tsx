import { usePosts } from "@/hooks/use-posts";
import { Navbar } from "@/components/Navbar";
import { PostCard } from "@/components/PostCard";
import { CreatePostDialog } from "@/components/CreatePostDialog";
import { Button } from "@/components/ui/button";
import { Skeleton } from "@/components/ui/skeleton";
import { TrendingUp, Users, Shield, Zap } from "lucide-react";

export default function Home() {
  const { data: posts, isLoading, error } = usePosts();

  return (
    <div className="min-h-screen bg-background pb-20">
      <Navbar />
      
      <main className="container max-w-6xl mx-auto px-4 pt-8 grid grid-cols-1 lg:grid-cols-12 gap-8">
        
        {/* Main Feed */}
        <div className="lg:col-span-8 space-y-6">
          <div className="flex items-center justify-between mb-4">
            <h2 className="text-xl font-display font-semibold text-foreground neon-text">
              Top Corporate Discussions
            </h2>
            <div className="flex gap-2">
              <Button variant="ghost" size="sm" className="text-primary bg-primary/10">Hot</Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">New</Button>
              <Button variant="ghost" size="sm" className="text-muted-foreground hover:text-foreground">Top</Button>
            </div>
          </div>

          {isLoading ? (
            <div className="space-y-4">
              {[1, 2, 3].map((i) => (
                <div key={i} className="h-40 bg-card/40 border border-white/5 rounded-xl animate-pulse" />
              ))}
            </div>
          ) : error ? (
            <div className="p-8 text-center bg-destructive/10 border border-destructive/20 rounded-xl">
              <p className="text-destructive font-medium">Failed to load feed</p>
            </div>
          ) : posts?.length === 0 ? (
            <div className="p-12 text-center bg-card/40 border border-white/5 rounded-xl">
              <p className="text-muted-foreground">No posts yet. Be the first!</p>
            </div>
          ) : (
            <div className="space-y-4">
              {posts?.map((post) => (
                <PostCard key={post.id} post={post} />
              ))}
            </div>
          )}
        </div>

        {/* Right Sidebar */}
        <div className="hidden lg:block lg:col-span-4 space-y-6">
          {/* Create Widget */}
          <div className="p-6 bg-gradient-to-br from-card to-card/50 border border-white/10 rounded-xl shadow-lg">
            <h3 className="text-lg font-display font-bold mb-2">Share Your Insights</h3>
            <p className="text-sm text-muted-foreground mb-4">
              Your perspective shapes the corporate galaxy.
            </p>
            <CreatePostDialog />
          </div>

          {/* Trending Communities Mock */}
          <div className="bg-card/40 border border-white/5 rounded-xl overflow-hidden">
            <div className="p-4 border-b border-white/5 bg-white/[0.02]">
              <h3 className="font-display font-bold text-sm uppercase tracking-wider text-muted-foreground flex items-center">
                <TrendingUp className="w-4 h-4 mr-2 text-accent" />
                Market Movers
              </h3>
            </div>
            <div className="divide-y divide-white/5">
              {[
                { name: "r/AI_Ethics", members: "125k", icon: Zap, color: "text-yellow-400" },
                { name: "r/Space_Mining", members: "84k", icon: Shield, color: "text-blue-400" },
                { name: "r/Executive_Lounge", members: "42k", icon: Users, color: "text-green-400" },
              ].map((community, i) => (
                <div key={i} className="flex items-center justify-between p-4 hover:bg-white/5 transition-colors cursor-pointer group">
                  <div className="flex items-center gap-3">
                    <community.icon className={`w-5 h-5 ${community.color}`} />
                    <div>
                      <p className="text-sm font-medium group-hover:text-primary transition-colors">{community.name}</p>
                      <p className="text-xs text-muted-foreground">{community.members} members</p>
                    </div>
                  </div>
                  <Button variant="outline" size="sm" className="h-7 text-xs border-white/10 hover:bg-primary hover:text-primary-foreground hover:border-primary">
                    Join
                  </Button>
                </div>
              ))}
            </div>
          </div>

          {/* Ad / Info */}
          <div className="relative overflow-hidden rounded-xl border border-white/5 group">
             {/* Descriptive comment for Unsplash Image */}
             {/* Tech futuristic city skyscraper */}
            <div className="absolute inset-0 bg-gradient-to-t from-black to-transparent z-10" />
            <img 
              src="https://images.unsplash.com/photo-1486406146926-c627a92ad1ab?w=800&q=80" 
              alt="Corporate Future" 
              className="w-full h-64 object-cover transition-transform duration-700 group-hover:scale-105"
            />
            <div className="absolute bottom-0 left-0 right-0 p-6 z-20">
              <p className="text-xs font-mono text-accent mb-1">SPONSORED</p>
              <h4 className="font-bold text-lg leading-tight mb-2">Molozon Premium</h4>
              <p className="text-sm text-gray-300 mb-3">Get advanced analytics and ad-free experience.</p>
              <Button size="sm" className="w-full bg-white text-black hover:bg-gray-200">
                Upgrade Now
              </Button>
            </div>
          </div>

          <div className="text-xs text-muted-foreground px-4 leading-relaxed">
            <div className="flex flex-wrap gap-2 mb-2">
              <span className="hover:underline cursor-pointer">About</span>
              <span className="hover:underline cursor-pointer">Careers</span>
              <span className="hover:underline cursor-pointer">Terms</span>
              <span className="hover:underline cursor-pointer">Privacy</span>
            </div>
            <p>© 2024 Molozon Inc. All rights reserved.</p>
          </div>
        </div>
      </main>
    </div>
  );
}
