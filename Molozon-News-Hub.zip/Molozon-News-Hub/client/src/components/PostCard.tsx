import { Link } from "wouter";
import { formatDistanceToNow } from "date-fns";
import { ArrowBigUp, ArrowBigDown, MessageSquare, Share2, MoreHorizontal } from "lucide-react";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { Button } from "@/components/ui/button";
import type { PostWithAuthor } from "@shared/schema";
import { cn } from "@/lib/utils";

interface PostCardProps {
  post: PostWithAuthor;
  isDetail?: boolean;
}

export function PostCard({ post, isDetail = false }: PostCardProps) {
  const authorName = post.author?.username || post.author?.firstName || "Anonymous Executive";
  
  return (
    <div className={cn(
      "flex bg-card/40 border border-white/5 overflow-hidden transition-all duration-300",
      !isDetail && "hover:border-primary/30 hover:bg-card/60 rounded-xl cursor-pointer group",
      isDetail && "rounded-t-xl border-b-0"
    )}>
      {/* Vote Sidebar */}
      <div className="w-12 bg-black/20 flex flex-col items-center py-3 gap-1 border-r border-white/5">
        <button className="text-muted-foreground hover:text-accent hover:bg-accent/10 p-1 rounded transition-colors">
          <ArrowBigUp className="w-6 h-6" />
        </button>
        <span className="text-xs font-bold text-foreground font-mono">
          {((post.upvotes || 0) - (post.downvotes || 0))}
        </span>
        <button className="text-muted-foreground hover:text-blue-500 hover:bg-blue-500/10 p-1 rounded transition-colors">
          <ArrowBigDown className="w-6 h-6" />
        </button>
      </div>

      {/* Content Area */}
      <div className="flex-1 p-4">
        {/* Meta Header */}
        <div className="flex items-center text-xs text-muted-foreground mb-2 gap-2">
          <Avatar className="h-5 w-5 ring-1 ring-white/10">
            <AvatarImage src={post.author?.profileImageUrl || undefined} />
            <AvatarFallback className="text-[10px] bg-secondary">
              {authorName[0]}
            </AvatarFallback>
          </Avatar>
          <span className="font-medium text-primary/80 hover:underline cursor-pointer">
            r/corporate
          </span>
          <span>•</span>
          <span>Posted by <span className="hover:text-foreground transition-colors">{authorName}</span></span>
          <span>•</span>
          <span>{formatDistanceToNow(new Date(post.createdAt || new Date()), { addSuffix: true })}</span>
        </div>

        {/* Title & Body */}
        <Link href={`/post/${post.id}`} className="block">
          <h3 className="text-lg md:text-xl font-display font-semibold text-foreground mb-2 group-hover:text-primary transition-colors leading-snug">
            {post.title}
          </h3>
          <div className={cn("text-muted-foreground text-sm leading-relaxed", !isDetail && "line-clamp-3")}>
            {post.content}
          </div>
        </Link>

        {/* Action Bar */}
        <div className="flex items-center gap-2 mt-4">
          <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-full" asChild>
            <Link href={`/post/${post.id}`}>
              <MessageSquare className="w-4 h-4 mr-2" />
              <span className="text-xs font-medium">Comments</span>
            </Link>
          </Button>
          
          <Button variant="ghost" size="sm" className="h-8 px-2 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-full">
            <Share2 className="w-4 h-4 mr-2" />
            <span className="text-xs font-medium">Share</span>
          </Button>
          
          <Button variant="ghost" size="sm" className="h-8 w-8 p-0 text-muted-foreground hover:text-foreground hover:bg-white/5 rounded-full ml-auto">
            <MoreHorizontal className="w-4 h-4" />
          </Button>
        </div>
      </div>
    </div>
  );
}
