import { Link, useLocation } from "wouter";
import { useAuth } from "@/hooks/use-auth";
import { Button } from "@/components/ui/button";
import { Avatar, AvatarFallback, AvatarImage } from "@/components/ui/avatar";
import { 
  DropdownMenu, 
  DropdownMenuContent, 
  DropdownMenuItem, 
  DropdownMenuTrigger 
} from "@/components/ui/dropdown-menu";
import { LogOut, User, Menu, Bell, Search } from "lucide-react";
import { useStocks } from "@/hooks/use-stocks";
import { cn } from "@/lib/utils";

function StockTicker() {
  const { data: stocks } = useStocks();

  // Mock data if empty
  const displayStocks = stocks && stocks.length > 0 ? stocks : [
    { id: 1, symbol: 'MOL', price: 12450, change: 250, name: 'Molozon Inc' },
    { id: 2, symbol: 'ZON', price: 4520, change: -120, name: 'Zon Corp' },
    { id: 3, symbol: 'GLX', price: 8900, change: 560, name: 'Galaxy Tech' },
    { id: 4, symbol: 'NEB', price: 3310, change: 15, name: 'Nebula AI' },
    { id: 5, symbol: 'VOID', price: 120, change: -5, name: 'Void Space' },
  ];

  return (
    <div className="bg-black/40 border-b border-border/50 h-8 flex items-center overflow-hidden whitespace-nowrap">
      <div className="flex animate-[scroll_30s_linear_infinite] hover:pause">
        {displayStocks.concat(displayStocks).map((stock, i) => (
          <div key={`${stock.symbol}-${i}`} className="flex items-center px-6 font-mono text-xs">
            <span className="font-bold text-muted-foreground mr-2">{stock.symbol}</span>
            <span className="text-foreground mr-2">{(stock.price / 100).toFixed(2)}</span>
            <span className={stock.change >= 0 ? "text-green-500" : "text-red-500"}>
              {stock.change >= 0 ? "▲" : "▼"} {Math.abs(stock.change / 100).toFixed(2)}
            </span>
          </div>
        ))}
      </div>
      <style>{`
        @keyframes scroll {
          0% { transform: translateX(0); }
          100% { transform: translateX(-50%); }
        }
        .hover\\:pause:hover {
          animation-play-state: paused;
        }
      `}</style>
    </div>
  );
}

export function Navbar() {
  const { user, logout } = useAuth();
  const [location] = useLocation();

  return (
    <div className="sticky top-0 z-50 flex flex-col w-full">
      {/* Main Nav */}
      <header className="h-16 bg-background/80 backdrop-blur-xl border-b border-white/5 flex items-center px-4 lg:px-8 justify-between">
        <div className="flex items-center gap-8">
          <Link href="/" className="flex items-center gap-2 group">
            <div className="w-8 h-8 rounded-full bg-gradient-to-tr from-primary to-accent group-hover:shadow-[0_0_15px_rgba(139,92,246,0.5)] transition-shadow duration-300" />
            <span className="font-display font-bold text-2xl tracking-tight text-white group-hover:text-primary transition-colors">
              MOLOZON
            </span>
          </Link>
          
          <nav className="hidden md:flex items-center gap-1">
            <Link href="/" className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-white/5",
              location === "/" ? "text-primary bg-primary/10" : "text-muted-foreground"
            )}>
              Feed
            </Link>
            <Link href="/markets" className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-white/5",
              location === "/markets" ? "text-primary bg-primary/10" : "text-muted-foreground"
            )}>
              Markets
            </Link>
            <Link href="/about" className={cn(
              "px-4 py-2 rounded-full text-sm font-medium transition-all hover:bg-white/5",
              location === "/about" ? "text-primary bg-primary/10" : "text-muted-foreground"
            )}>
              Corporate
            </Link>
          </nav>
        </div>

        <div className="flex items-center gap-4">
          <div className="hidden lg:flex relative group">
            <div className="absolute inset-y-0 left-0 pl-3 flex items-center pointer-events-none">
              <Search className="h-4 w-4 text-muted-foreground" />
            </div>
            <input 
              type="text" 
              placeholder="Search Molozon..." 
              className="pl-10 pr-4 py-1.5 bg-secondary/50 border border-transparent rounded-full text-sm w-64 focus:outline-none focus:border-primary/50 focus:bg-secondary transition-all"
            />
          </div>

          <button className="text-muted-foreground hover:text-foreground transition-colors p-2 rounded-full hover:bg-white/5 relative">
            <Bell className="w-5 h-5" />
            <span className="absolute top-2 right-2 w-2 h-2 bg-accent rounded-full animate-pulse" />
          </button>

          {user ? (
            <DropdownMenu>
              <DropdownMenuTrigger asChild>
                <button className="flex items-center gap-2 pl-1 pr-2 py-1 rounded-full border border-white/5 hover:bg-white/5 transition-all outline-none focus:ring-2 focus:ring-primary/20">
                  <Avatar className="h-8 w-8 border border-white/10">
                    <AvatarImage src={user.profileImageUrl || undefined} />
                    <AvatarFallback className="bg-primary/20 text-primary text-xs">
                      {user.firstName?.[0] || user.email?.[0] || "U"}
                    </AvatarFallback>
                  </Avatar>
                  <span className="hidden sm:block text-sm font-medium text-foreground pr-2">
                    {user.firstName || "User"}
                  </span>
                </button>
              </DropdownMenuTrigger>
              <DropdownMenuContent align="end" className="w-56 bg-card border-white/10 text-foreground">
                <DropdownMenuItem className="focus:bg-primary/10 focus:text-primary cursor-pointer">
                  <User className="mr-2 h-4 w-4" />
                  <span>Profile</span>
                </DropdownMenuItem>
                <DropdownMenuItem onClick={() => logout()} className="focus:bg-destructive/10 focus:text-destructive cursor-pointer text-destructive">
                  <LogOut className="mr-2 h-4 w-4" />
                  <span>Log out</span>
                </DropdownMenuItem>
              </DropdownMenuContent>
            </DropdownMenu>
          ) : (
            <div className="flex items-center gap-2">
              <Button variant="ghost" className="text-muted-foreground hover:text-white" asChild>
                <a href="/api/login">Log In</a>
              </Button>
              <Button className="bg-primary hover:bg-primary/90 text-primary-foreground shadow-[0_0_15px_rgba(139,92,246,0.3)]" asChild>
                <a href="/api/login">Sign Up</a>
              </Button>
            </div>
          )}
        </div>
      </header>
      <StockTicker />
    </div>
  );
}
