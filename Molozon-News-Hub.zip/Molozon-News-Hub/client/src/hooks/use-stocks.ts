import { useQuery } from "@tanstack/react-query";
import { api } from "@shared/routes";

export function useStocks() {
  return useQuery({
    queryKey: [api.stocks.list.path],
    queryFn: async () => {
      const res = await fetch(api.stocks.list.path, { credentials: "include" });
      if (!res.ok) throw new Error("Failed to fetch market data");
      return api.stocks.list.responses[200].parse(await res.json());
    },
    refetchInterval: 5000, // Refresh every 5s for "live" feel
  });
}
