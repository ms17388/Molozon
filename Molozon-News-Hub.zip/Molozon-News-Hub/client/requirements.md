## Packages
framer-motion | Complex animations for the "galaxy" feel and page transitions
lucide-react | Icons for the UI
date-fns | Formatting timestamps for posts/comments
clsx | Utility for constructing className strings
tailwind-merge | Utility for merging Tailwind classes

## Notes
Tailwind Config - extend fontFamily:
fontFamily: {
  display: ["var(--font-display)"],
  body: ["var(--font-body)"],
  mono: ["var(--font-mono)"],
}
